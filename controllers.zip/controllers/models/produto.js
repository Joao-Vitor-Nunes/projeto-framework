class Livro {
   listar(){
        return [
            {id: 1, nome: 'Produto', preco: '20.00'},
            {id: 2, nome: 'Produto', preco: '30.00'},
            {id: 3, nome: 'Produto', preco: '40.00'}
        ]
   } 
}

module.exports( Livro )